#include "common/xf_headers.hpp"
#include "xf_config_params.h"
int main(int argc, char **argv)
{

    cv::Mat in_src, in_src_2, in_brga, in_accel, in_ref, in_ref_2;
    cv::Mat dark_out, img_r_channel, img_g_channel, img_b_channel;
    // read image
    in_src = cv::imread(argv[1], 1);
    in_src_2 = cv::imread(argv[2], 1);
    in_src.convertTo(in_ref, CV_IN_TYPE);
    in_src_2.convertTo(in_ref_2, CV_IN_TYPE);
    if (in_src.data == NULL)
    {

        fprintf(stderr, "Cannot open image \n");
        return 0;
    }

    dark_out.create(in_ref.rows, in_ref.cols, CV_8UC3);
    img_r_channel.create(in_ref.rows, in_ref.cols, CV_OUT_TYPE);
    img_g_channel.create(in_ref.rows, in_ref.cols, CV_OUT_TYPE);
    img_b_channel.create(in_ref.rows, in_ref.cols, CV_OUT_TYPE);
    if (RGB)
    {

        in_ref.copyTo(in_accel);
    }
    else if (RGBA)
    {

        cv::cvtColor(in_ref, in_accel, cv::COLOR_BGR2BGRA);
    }

    int height = in_accel.rows;
    int width = in_accel.cols;
    // Call the top function
    main_function(
        (ap_uint<INPUT_PTR_WIDTH> *)in_ref.data,
		(ap_uint<INPUT_PTR_WIDTH> *)in_ref_2.data,
        (ap_uint<INPUT_PTR_WIDTH> *)dark_out.data,
        height, width);
    cv::imwrite("img_min_mat.png", dark_out);
    return 0;
}
