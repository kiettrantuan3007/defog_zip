#include "xf_config_params.h"
#include "defog_utility.h"
static constexpr int __XF_DEPTH = (HEIGHT * WIDTH * (XF_PIXELWIDTH(IN_TYPE, NPPCX)) / 8) / (INPUT_PTR_WIDTH / 8);
void main_function(ap_uint<INPUT_PTR_WIDTH> *img_input_1,
		ap_uint<INPUT_PTR_WIDTH> *img_input_2,
		ap_uint<INPUT_PTR_WIDTH> *img_output, int rows, int cols)
{
	
#pragma HLS INTERFACE m_axi port = img_input_1 offset = slave bundle = gmem1 depth = __XF_DEPTH
#pragma HLS INTERFACE m_axi port = img_input_2 offset = slave bundle = gmem2 depth = __XF_DEPTH
#pragma HLS INTERFACE m_axi port = img_output offset = slave bundle = gmem3 depth = __XF_DEPTH
#pragma HLS INTERFACE s_axilite port = rows bundle = control
#pragma HLS INTERFACE s_axilite port = cols bundle = control
#pragma HLS INTERFACE s_axilite port = return bundle = control

	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> darkChannel;
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> darkChannel_1;
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> imgRestore_gray;
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> min_mat;
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> factor;
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> imgInput;
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> imgInput_1;
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> imgInput_2;
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> imgRestore;
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> imgOutput;
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> imgRestore_1;
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> imgRestore_2;
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> imgRestore_2_delay;

#pragma HLS stream variable=darkChannel.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=darkChannel_1.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=imgRestore_gray.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=min_mat.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=factor.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=imgInput.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=imgInput_1.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=imgInput_2.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=imgRestore.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=imgOutput.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=imgRestore_1.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=imgRestore_2.data depth=_XFCVDEPTH_DEFAULT

	unsigned char lut_buff[256];
	uint32_t histogram[256];
#pragma HLS DATAFLOW
	xf::cv::Array2xfMat<INPUT_PTR_WIDTH, IN_TYPE, HEIGHT, WIDTH, NPPCX>(img_input_1, imgInput_1);
	xf::cv::Array2xfMat<INPUT_PTR_WIDTH, IN_TYPE, HEIGHT, WIDTH, NPPCX>(img_input_2, imgInput_2);
	minmat_accel(imgInput_1, min_mat);
	darkChannel_accel(min_mat, darkChannel);
	findRestore_out(imgInput_2, darkChannel, imgRestore);

	xf::cv::duplicateMat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT, _XFCVDEPTH_DEFAULT, _XFCVDEPTH_DEFAULT>
		(imgRestore, imgRestore_1, imgRestore_2);
	xf::cv::rgb2gray<IN_TYPE, OUT_TYPE, HEIGHT, WIDTH, NPPCX>(imgRestore_1, imgRestore_gray);
	xf::cv::calcHist<OUT_TYPE, HEIGHT, WIDTH, NPPCX>(imgRestore_gray, &histogram[0]);
	find_LUT(&lut_buff[0], &histogram[0],  rows, cols);
	xf::cv::delayMat<300000, IN_TYPE, HEIGHT, WIDTH>(imgRestore_2, imgRestore_2_delay);
	xf::cv::LUT<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT, _XFCVDEPTH_DEFAULT>(imgRestore_2_delay, imgOutput, &lut_buff[0]);
	xf::cv::xfMat2Array<INPUT_PTR_WIDTH, IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT>(imgOutput, img_output);

	return;
}
