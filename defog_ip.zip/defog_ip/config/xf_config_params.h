#ifndef _XF_CHANNEL_EXTRACT_CONFIG_H_
#define _XF_CHANNEL_EXTRACT_CONFIG_H_
#include "hls_stream.h"
#include "ap_int.h"
#include "common/xf_common.hpp"
#include "common/xf_utility.hpp"
#include "imgproc/xf_channel_extract.hpp"
#include "imgproc/xf_crop.hpp"
#include "imgproc/xf_custom_convolution.hpp"
#include "core/xf_arithm.hpp"
#include "imgproc/xf_channel_combine.hpp"
#include "imgproc/xf_cvt_color.hpp"
#include "imgproc/xf_histogram.hpp"
#include <cmath>
#include "imgproc/xf_convertscaleabs.hpp"
#include "imgproc/xf_lut.hpp"
#include "imgproc/xf_delay.hpp"
#include "imgproc/xf_duplicateimage.hpp"

// Image width and height
#define HEIGHT 600
#define WIDTH 800
#define XF_CV_DEPTH_IN_1 2
#define XF_CV_DEPTH_OUT_1 2
#define T_8U 1
#define T_16U 0
#define RGB 1
#define RGBA 0
#define NPPCX XF_NPPC1
#define IN_TYPE XF_8UC3
#define OUT_TYPE XF_8UC1
#define CV_IN_TYPE CV_8UC3
#define CV_OUT_TYPE CV_8UC1
#define INPUT_PTR_WIDTH 32
#define OUTPUT_PTR_WIDTH 8
#endif
//_XF_CHANNEL_EXTRACT_CONFIG_H_
void main_function(ap_uint<INPUT_PTR_WIDTH> *img_input_1, ap_uint<INPUT_PTR_WIDTH> *img_input_2, ap_uint<INPUT_PTR_WIDTH> *img_output, int rows, int cols);
