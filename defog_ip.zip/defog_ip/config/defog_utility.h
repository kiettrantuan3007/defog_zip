#include "xf_config_params.h"

template <int BUS_WIDTH,
		  int TYPE,
		  int ROWS,
		  int COLS,
		  int NPPC,
		  int XFCVDEPTH_IN = _XFCVDEPTH_DEFAULT,
		  int XFCVDEPTH_OUT = _XFCVDEPTH_DEFAULT>
void xfTriple(xf::cv::Mat<TYPE, ROWS, COLS, NPPC, XFCVDEPTH_IN> &in_mat,
			  xf::cv::Mat<TYPE, ROWS, COLS, NPPC, XFCVDEPTH_OUT> &out_mat_1,
			  xf::cv::Mat<TYPE, ROWS, COLS, NPPC, XFCVDEPTH_OUT> &out_mat_2,
			  xf::cv::Mat<TYPE, ROWS, COLS, NPPC, XFCVDEPTH_OUT> &out_mat_3)
{
#pragma HLS INLINE OFF

	const int c_TRIP_COUNT = ROWS * COLS;
	int loopcount = ROWS * (COLS >> XF_BITSHIFT(NPPC));

	for (int i = 0; i < loopcount; i++)
	{
#pragma HLS pipeline II = 1
#pragma HLS LOOP_TRIPCOUNT min = c_TRIP_COUNT max = c_TRIP_COUNT
		XF_TNAME(TYPE, NPPC)
		tmp = in_mat.read(i);
		out_mat_1.write(i, tmp);
		out_mat_2.write(i, tmp);
		out_mat_3.write(i, tmp);
	}
}

void minmat_accel(
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> &imgInput,
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> &min_mat)
{
#pragma HLS DATAFLOW
	int loopcount = HEIGHT * (WIDTH >> XF_BITSHIFT(NPPCX));
	for (int i = 0; i < loopcount; i++)
	{
		const ap_uint<INPUT_PTR_WIDTH> dataPixel = imgInput.read(i);
#pragma HLS pipeline II = 4

		XF_TNAME(OUT_TYPE, NPPCX) final_temp, tmp_1 = dataPixel.range(23, 16);
		XF_TNAME(OUT_TYPE, NPPCX) tmp_2 = dataPixel.range(15, 8);
		XF_TNAME(OUT_TYPE, NPPCX) tmp_3 = dataPixel.range(7, 0);
		if (final_temp > tmp_1)
		{
			final_temp = tmp_1;
		}
		if (final_temp > tmp_2)
		{
			final_temp = tmp_2;
		}
		if (final_temp > tmp_3)
		{
			final_temp = tmp_3;
		}
		const XF_TNAME(OUT_TYPE, NPPCX) write_data = final_temp;
		min_mat.write(i, write_data);
	}
}

void darkChannel_accel(
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> &min_mat,
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> &darkChannel)
{

	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> temp1;
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> temp2;
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> temp3;
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> temp_dark_filter;
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> temp_dark_channel;
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> temp_min_mat_1;
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, 2096222> temp_min_mat_2;

#pragma HLS stream variable = temp1.data depth = _XFCVDEPTH_DEFAULT
#pragma HLS stream variable = temp2.data depth = _XFCVDEPTH_DEFAULT
#pragma HLS stream variable = temp3.data depth = _XFCVDEPTH_DEFAULT
#pragma HLS stream variable = temp_dark_filter.data depth = _XFCVDEPTH_DEFAULT
#pragma HLS stream variable = temp_dark_channel.data depth = _XFCVDEPTH_DEFAULT
#pragma HLS stream variable = temp_min_mat_1.data depth = _XFCVDEPTH_DEFAULT
#pragma HLS stream variable = temp_min_mat_2.data depth = 2096222

	short int filter_ptr[9] = {2048, 4096, 2048,
							   4096, 8192, 4092,
							   2048, 4096, 2048};
#pragma HLS DATAFLOW
	xf::cv::duplicateMat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT, _XFCVDEPTH_DEFAULT, 2096222>(min_mat, temp_min_mat_1, temp_min_mat_2);
	xf::cv::convertScaleAbs<OUT_TYPE, OUT_TYPE, HEIGHT, WIDTH, NPPCX>(temp_min_mat_1, temp1, 0.9, 0);
	xf::cv::filter2D<XF_BORDER_CONSTANT, 3, 3, OUT_TYPE, OUT_TYPE, HEIGHT, WIDTH, NPPCX>(temp1, temp2, &filter_ptr[0], 15);
	xf::cv::filter2D<XF_BORDER_CONSTANT, 3, 3, OUT_TYPE, OUT_TYPE, HEIGHT, WIDTH, NPPCX>(temp2, temp3, &filter_ptr[0], 15);
	xf::cv::filter2D<XF_BORDER_CONSTANT, 3, 3, OUT_TYPE, OUT_TYPE, HEIGHT, WIDTH, NPPCX>(temp3, temp_dark_filter, &filter_ptr[0], 15);
	xf::cv::min<OUT_TYPE, HEIGHT, WIDTH, NPPCX, 2096222, _XFCVDEPTH_DEFAULT, _XFCVDEPTH_DEFAULT>(temp_min_mat_2, temp_dark_filter, temp_dark_channel);
	xf::cv::convertScaleAbs<OUT_TYPE, OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT, _XFCVDEPTH_DEFAULT>(temp_dark_channel, darkChannel, 0.6, 0);
}

void findRestore_out(
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> &img_input,
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> &diffin,
	xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> &restore_out_1)
{
#pragma HLS DATAFLOW
	xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> restore_out_r, restore_out_g, restore_out_b;
#pragma HLS stream variable = restore_out_r.data depth = _XFCVDEPTH_DEFAULT
#pragma HLS stream variable = restore_out_g.data depth = _XFCVDEPTH_DEFAULT
#pragma HLS stream variable = restore_out_b.data depth = _XFCVDEPTH_DEFAULT
    xf::cv::Mat<IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> color_R, color_G, color_B;
#pragma HLS stream variable=color_R.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=color_G.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=color_B.data depth=_XFCVDEPTH_DEFAULT
    xf::cv::Mat<OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT> channel_r, channel_g, channel_b;
#pragma HLS stream variable=channel_r.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=channel_g.data depth=_XFCVDEPTH_DEFAULT
#pragma HLS stream variable=channel_b.data depth=_XFCVDEPTH_DEFAULT
    xfTriple<32, IN_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT>(img_input, color_R, color_G, color_B);
    	xf::cv::extractChannel<IN_TYPE, OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT, _XFCVDEPTH_DEFAULT>(color_R, channel_r, 4);
    	xf::cv::extractChannel<IN_TYPE, OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT, _XFCVDEPTH_DEFAULT>(color_G, channel_g, 5);
    	xf::cv::extractChannel<IN_TYPE, OUT_TYPE, HEIGHT, WIDTH, NPPCX, _XFCVDEPTH_DEFAULT, _XFCVDEPTH_DEFAULT>(color_B, channel_b, 6);
	int loopcount = HEIGHT * (WIDTH >> XF_BITSHIFT(NPPCX));
	for (int i = 0; i < loopcount; i++)
	{
#pragma HLS pipeline II = 1
#pragma HLS loop_flatten off
//		const ap_uint<32> dataPixel = img_input.read(i);
		XF_TNAME(OUT_TYPE, NPPCX) dataPixel_r = channel_r.read(i);
		XF_TNAME(OUT_TYPE, NPPCX) dataPixel_g = channel_g.read(i);
		XF_TNAME(OUT_TYPE, NPPCX) dataPixel_b = channel_b.read(i);

		const XF_TNAME(OUT_TYPE, NPPCX) diffin_v = diffin.read(i);
		float index_float = (float)diffin_v;
		float factor_v = (255.0 / (255.0 - index_float));

		restore_out_r.write(i, (XF_TNAME(OUT_TYPE, NPPCX)(dataPixel_r - diffin_v) * factor_v));
		restore_out_g.write(i, (XF_TNAME(OUT_TYPE, NPPCX)(dataPixel_g - diffin_v) * factor_v));
		restore_out_b.write(i, (XF_TNAME(OUT_TYPE, NPPCX)(dataPixel_b - diffin_v) * factor_v));
	}
	xf::cv::merge<OUT_TYPE, IN_TYPE, HEIGHT, WIDTH, NPPCX>(restore_out_r, restore_out_g, restore_out_b, restore_out_1);
}

void find_LUT(unsigned char *lut_buff, uint32_t *histogram, int rows, int cols)
{
	float prob;
	float cdf[256];
	const float size = rows * cols;
	int length = 0;
	cdf[0] = (float)(histogram[0]) / size;
find_cdf_loop:

	for (int i = 0; i < 256; i++)
	{
		prob = (float)(histogram[i]) / size;
		cdf[i] = cdf[i - 1] + prob;
	}
find_length:

	for (int i = 0; i < 256; i++)
	{
#pragma HLS PIPELINE
		if (cdf[i] > 0.1)
		{
			length = i;
			break;
		}
	}
	int i2 = 255 - length;
	float o1 = (255.0 * 0.1);
	float o2 = (255.0 * 0.9);
find_lut_buff:

	for (int i = 0; i <= length; i++)
	{
		lut_buff[i] = (unsigned char)(o1 / length) * i;
	}
	for (int i = length; i <= i2; i++)
	{
		lut_buff[i] = (unsigned char)(((o2 - o1) / (i2 - length) * i) - (((o2 - o1) / (i2 - length)) * length) + o1);
	}
	for (int i = i2; i <= 256; i++)
	{
		lut_buff[i] = (unsigned char)((((255 - o2) / (255 - i2)) * i) - (((255 - o2) / (255 - i2)) * i2) + o2);
	}
}
